#!/bin/bash

# ============================================
# 🦞 Lobster School — Graduation Package Installer
# ============================================
#
# Installs the Lobster School graduation package into your
# OpenClaw workspace. Backs up everything first.
#
# Usage:
#   ./install.sh                           # Uses default ~/.openclaw/workspace
#   ./install.sh /path/to/custom/workspace # Uses custom workspace path
#
# Undo: ./uninstall.sh [same path]
# ============================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo ""
echo -e "${BLUE}🦞 Lobster School — Graduation Package Installer${NC}"
echo "================================================="
echo ""

# Default to standard OpenClaw workspace
WORKSPACE="${1:-$HOME/.openclaw/workspace}"
OPENCLAW_DIR="$HOME/.openclaw"
OPENCLAW_CONFIG="$OPENCLAW_DIR/openclaw.json"
SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
GRAD_DIR="$SCRIPT_DIR/graduation-package"
BACKUP_DIR="$WORKSPACE/.lobster-backup/$(date +%Y%m%d_%H%M%S)"
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

# Verify OpenClaw is installed
if [ ! -d "$OPENCLAW_DIR" ]; then
    echo -e "${RED}Error: OpenClaw directory not found at $OPENCLAW_DIR${NC}"
    echo ""
    echo "It looks like OpenClaw isn't installed yet. Install it first:"
    echo "  npm install -g openclaw"
    echo "  openclaw onboard"
    echo ""
    echo "Then run this installer again."
    exit 1
fi

# Verify workspace exists
if [ ! -d "$WORKSPACE" ]; then
    echo -e "${YELLOW}Warning: Workspace not found at $WORKSPACE${NC}"
    echo "Creating it..."
    mkdir -p "$WORKSPACE"
fi

# Verify graduation package exists
if [ ! -d "$GRAD_DIR" ]; then
    echo -e "${RED}Error: Graduation package not found at $GRAD_DIR${NC}"
    echo "Make sure you're running this from the lobster-school/scripts directory."
    exit 1
fi

echo -e "${GREEN}OpenClaw dir: ${NC} $OPENCLAW_DIR"
echo -e "${GREEN}Workspace:    ${NC} $WORKSPACE"
echo -e "${GREEN}Backup to:    ${NC} $BACKUP_DIR"
echo ""

# ============================================
# Step 1: Create backup
# ============================================
echo -e "${BLUE}Step 1: Backing up current configuration...${NC}"

mkdir -p "$BACKUP_DIR"

# Backup workspace files
for file in BOOT.md HEARTBEAT.md AGENTS.md SOUL.md USER.md; do
    if [ -f "$WORKSPACE/$file" ]; then
        cp "$WORKSPACE/$file" "$BACKUP_DIR/$file"
        echo "  Backed up: workspace/$file"
    fi
done

# Backup main config
if [ -f "$OPENCLAW_CONFIG" ]; then
    cp "$OPENCLAW_CONFIG" "$BACKUP_DIR/openclaw.json"
    echo "  Backed up: openclaw.json"
fi

# Backup existing diploma skill
if [ -d "$WORKSPACE/skills/lobster-diploma" ]; then
    mkdir -p "$BACKUP_DIR/skills"
    cp -r "$WORKSPACE/skills/lobster-diploma" "$BACKUP_DIR/skills/"
    echo "  Backed up: skills/lobster-diploma/"
fi

echo -e "${GREEN}  ✓ Backup complete${NC}"
echo ""

# ============================================
# Step 2: Install BOOT.md
# ============================================
echo -e "${BLUE}Step 2: Installing BOOT.md (session start ritual)...${NC}"

if [ -f "$WORKSPACE/BOOT.md" ]; then
    if grep -q "Lobster School" "$WORKSPACE/BOOT.md"; then
        echo -e "${YELLOW}  Already contains Lobster School content. Replacing...${NC}"
        cp "$GRAD_DIR/BOOT.md" "$WORKSPACE/BOOT.md"
    else
        # Prepend our boot before existing content
        cat "$GRAD_DIR/BOOT.md" > "$WORKSPACE/BOOT.md.tmp"
        echo "" >> "$WORKSPACE/BOOT.md.tmp"
        echo "---" >> "$WORKSPACE/BOOT.md.tmp"
        echo "" >> "$WORKSPACE/BOOT.md.tmp"
        echo "## Your Original Boot Instructions" >> "$WORKSPACE/BOOT.md.tmp"
        echo "" >> "$WORKSPACE/BOOT.md.tmp"
        cat "$WORKSPACE/BOOT.md" >> "$WORKSPACE/BOOT.md.tmp"
        mv "$WORKSPACE/BOOT.md.tmp" "$WORKSPACE/BOOT.md"
        echo -e "${GREEN}  ✓ Prepended to existing BOOT.md${NC}"
    fi
else
    cp "$GRAD_DIR/BOOT.md" "$WORKSPACE/BOOT.md"
    echo -e "${GREEN}  ✓ BOOT.md installed${NC}"
fi
echo ""

# ============================================
# Step 3: Install HEARTBEAT.md
# ============================================
echo -e "${BLUE}Step 3: Installing HEARTBEAT.md (periodic monitoring)...${NC}"

if [ -f "$WORKSPACE/HEARTBEAT.md" ]; then
    if grep -q "Lobster School" "$WORKSPACE/HEARTBEAT.md"; then
        echo -e "${YELLOW}  Already contains Lobster School content. Replacing...${NC}"
        cp "$GRAD_DIR/HEARTBEAT.md" "$WORKSPACE/HEARTBEAT.md"
    else
        echo "" >> "$WORKSPACE/HEARTBEAT.md"
        echo "---" >> "$WORKSPACE/HEARTBEAT.md"
        echo "" >> "$WORKSPACE/HEARTBEAT.md"
        cat "$GRAD_DIR/HEARTBEAT.md" >> "$WORKSPACE/HEARTBEAT.md"
        echo -e "${GREEN}  ✓ Appended to existing HEARTBEAT.md${NC}"
    fi
else
    cp "$GRAD_DIR/HEARTBEAT.md" "$WORKSPACE/HEARTBEAT.md"
    echo -e "${GREEN}  ✓ HEARTBEAT.md installed${NC}"
fi
echo ""

# ============================================
# Step 4: Append behavioral rules to AGENTS.md
# ============================================
echo -e "${BLUE}Step 4: Adding behavioral rules to AGENTS.md...${NC}"

if [ -f "$WORKSPACE/AGENTS.md" ]; then
    if grep -q "Lobster School Graduate" "$WORKSPACE/AGENTS.md"; then
        echo -e "${YELLOW}  Already contains Lobster School rules. Skipping.${NC}"
    else
        echo "" >> "$WORKSPACE/AGENTS.md"
        echo "" >> "$WORKSPACE/AGENTS.md"
        echo "---" >> "$WORKSPACE/AGENTS.md"
        echo "" >> "$WORKSPACE/AGENTS.md"
        cat "$GRAD_DIR/agents-lobster-addendum.md" >> "$WORKSPACE/AGENTS.md"
        echo -e "${GREEN}  ✓ Behavioral rules appended to AGENTS.md${NC}"
    fi
else
    cp "$GRAD_DIR/agents-lobster-addendum.md" "$WORKSPACE/AGENTS.md"
    echo -e "${GREEN}  ✓ AGENTS.md created with Lobster School rules${NC}"
fi
echo ""

# ============================================
# Step 5: Install hardened configuration
# ============================================
echo -e "${BLUE}Step 5: Security configuration...${NC}"

if [ -f "$OPENCLAW_CONFIG" ]; then
    echo "  Existing openclaw.json found. Saving hardened reference config."
    cp "$GRAD_DIR/openclaw-hardened.json" "$OPENCLAW_DIR/openclaw-hardened-reference.json"
    echo ""
    echo -e "${YELLOW}  ⚠ REVIEW & MERGE these settings into your openclaw.json:${NC}"
    echo ""
    echo "    gateway.bind: \"loopback\"         (localhost only)"
    echo "    gateway.auth.token: [set one]     (require auth)"
    echo "    session.dmScope: \"per-channel-peer\" (prevent context leakage)"
    echo "    channels.*.dmPolicy: \"pairing\"    (require pairing for DMs)"
    echo "    agent.heartbeat.every: \"15m\"      (enable heartbeat)"
    echo "    agent.elevated.enabled: false      (no elevated mode by default)"
    echo "    agents.defaults.sandbox.mode: \"non-main\" (sandbox group sessions)"
    echo ""
    echo "  Or apply all at once with:"
    echo "    openclaw config set gateway.bind loopback"
    echo "    openclaw config set gateway.auth.token \$(openssl rand -hex 32)"
    echo "    openclaw config set session.dmScope per-channel-peer"
    echo "    openclaw config set agent.heartbeat.every 15m"
    echo "    openclaw config set agent.elevated.enabled false"
    echo ""
    echo -e "${GREEN}  ✓ Reference config saved to ~/.openclaw/openclaw-hardened-reference.json${NC}"
else
    # Fresh install — generate config with random token
    TOKEN=$(openssl rand -hex 32 2>/dev/null || head -c 64 /dev/urandom | od -A n -t x1 | tr -d ' \n' | head -c 64)
    sed "s/REPLACE_WITH_STRONG_RANDOM_TOKEN/$TOKEN/" "$GRAD_DIR/openclaw-hardened.json" > "$OPENCLAW_CONFIG"
    echo -e "${GREEN}  ✓ openclaw.json installed with hardened defaults${NC}"
    echo -e "${YELLOW}  Gateway auth token: $TOKEN${NC}"
    echo "  Save this somewhere safe."
fi
echo ""

# ============================================
# Step 6: Install diploma skill
# ============================================
echo -e "${BLUE}Step 6: Installing lobster-diploma skill...${NC}"

mkdir -p "$WORKSPACE/skills/lobster-diploma"
cp "$GRAD_DIR/lobster-diploma/SKILL.md" "$WORKSPACE/skills/lobster-diploma/SKILL.md"
echo -e "${GREEN}  ✓ lobster-diploma skill installed${NC}"
echo ""

# ============================================
# Step 7: Ensure memory directory exists
# ============================================
echo -e "${BLUE}Step 7: Ensuring memory directory exists...${NC}"

mkdir -p "$WORKSPACE/memory"
echo -e "${GREEN}  ✓ memory/ directory ready${NC}"
echo ""

# ============================================
# Step 8: Write installation record
# ============================================
echo -e "${BLUE}Step 8: Writing installation record...${NC}"

cat > "$WORKSPACE/.lobster-school" << EOF
{
  "installed_at": "$TIMESTAMP",
  "version": "1.1.0",
  "backup_location": "$BACKUP_DIR",
  "components": [
    "BOOT.md",
    "HEARTBEAT.md",
    "agents-lobster-addendum (appended to AGENTS.md)",
    "openclaw-hardened.json (reference config)",
    "skills/lobster-diploma/SKILL.md"
  ]
}
EOF
echo -e "${GREEN}  ✓ Installation record saved${NC}"
echo ""

# ============================================
# Step 9: Validate
# ============================================
echo -e "${BLUE}Step 9: Validation...${NC}"

if command -v openclaw &> /dev/null; then
    echo "  Running openclaw doctor..."
    openclaw doctor --fix 2>&1 | head -20 || echo -e "${YELLOW}  Doctor check had issues — review above.${NC}"
else
    echo -e "${YELLOW}  openclaw CLI not found in PATH — skipping validation.${NC}"
    echo "  Run 'openclaw doctor --fix' manually after installation."
fi
echo ""

# ============================================
# Done!
# ============================================
echo "================================================="
echo -e "${GREEN}🦞 Graduation package installed!${NC}"
echo "================================================="
echo ""
echo "Installed to: $WORKSPACE"
echo "Backup at:    $BACKUP_DIR"
echo ""
echo "  ✓ BOOT.md          — Wake-up ritual every session"
echo "  ✓ HEARTBEAT.md     — Memory preservation + integrity checks"
echo "  ✓ AGENTS.md        — Source verification + action safety rules"
echo "  ✓ lobster-diploma   — Quick-reference decision skill"
echo ""
echo "To undo: ./scripts/uninstall.sh"
echo ""
echo -e "${BLUE}Restart your agent to activate: openclaw gateway restart${NC}"
echo ""
echo "Your agent will run the Lobster School boot sequence on next session. 🦞"
echo ""
